<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\dell\Desktop\laravel-projects\secondMindAdmin\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>