
<?php $__env->startSection('title', 'AI Agent Create'); ?>
<?php $__env->startSection('style'); ?>
<style>
 .image-box{
  max-width: 80px;
  max-height: 80px;
  border-radius:50%;
  padding: 5px;
  display: flex;
  justify-content:center;
  align-items:center;
  background-color:#fff;
 }
 .image-box img{
  width: 100%;
  height:100%;
 }
 .height-ai{
  height:100px;
 }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12 mb-lg-0 mb-4">
        <div class="card mt-4 pb-4">
            <div class="card-header pb-0 p-3">
                <div class="row">
                    <div class="col-6 d-flex align-items-center">
                        <h6 class="mb-0">AI Agents</h6>
                    </div>
                    <div class="col-6 text-end">
                        <a class="btn bg-gradient-dark mb-0" data-bs-toggle="modal" data-bs-target="#addAgent" href="javascript:;"><i class="fas fa-plus"></i>&nbsp;&nbsp;Add New Agent</a>
                    </div>

                    <!-- Modal -->
                    <div class="modal modal-lg fade" id="addAgent" tabindex="-1" role="dialog" aria-labelledby="addAgentLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-top" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="addAgentLabel">Modal title</h5>
                                    <button type="button" class="btn-close text-dark" data-bs-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    ...
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="button" class="btn bg-gradient-primary">Save changes</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body pt-4 p-3">
                <?php
                $cards = [
                    [
                        'name' => 'Aditi',
                        'type' => 'Viking Burrito',
                        'description' => 'As an AI Agent you need to tell people about the product its availability',
                        'document' => 'FRB1235476',
                    ],
                    [
                        'name' => 'Aditi',
                        'type' => 'Viking Burrito',
                        'description' => 'As an AI Agent you need to tell people about the product its availability',
                        'document' => 'FRB1235476',
                    ],
                    [
                        'name' => 'Aditi',
                        'type' => 'Data Whisperer',
                        'description' => 'Helps answer questions based on document data',
                        'document' => 'DOC654321',
                    ],
                    [
                        'name' => 'Aditi',
                        'type' => 'PDF Analyst',
                        'description' => 'Summarizes and explains content from PDF uploads',
                        'document' => 'PDF998877',
                    ]
                ];

                // Define 4 static styles
                $bg_classes = ['bg-gradient-primary', 'bg-gradient-info', 'bg-gradient-warning', 'bg-gradient-success'];
                $border_colors = ['#f39511', '#0aabe0', '#f1920f', '#5fd944'];
                ?>

                <div class="row">
                <?php foreach ($cards as $index => $card): ?>
                    <?php
                        $bg_class = $bg_classes[$index % 4]; // ensures no repeat if exactly 4
                        $border_color = $border_colors[$index % 4];
                    ?>
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header <?= $bg_class ?> height-ai"></div>
                            <div class="w-100 d-flex justify-content-center" style="margin-top:-40px;">
                                <div class="image-box" style="border:3px solid <?= $border_color ?>;">
                                    <img src="assets/img/robot.png" />
                                </div>
                            </div>
                            <div class="card-body p-0">
                                <h6 class="m-3 text-sm text-center"><?= htmlspecialchars($card['name']) ?></h6>
                                <div class="d-flex flex-column px-4">
                                    <span class="mb-2 text-xs">Type:
                                        <span class="text-dark font-weight-bold ms-sm-2"><?= htmlspecialchars($card['type']) ?></span></span>
                                    <span class="mb-2 text-xs">Description:
                                        <span class="text-dark ms-sm-2 font-weight-bold"><?= htmlspecialchars($card['description']) ?></span></span>
                                    <span class="mb-2 text-xs">From Document:
                                        <span class="text-dark ms-sm-2 font-weight-bold"><?= htmlspecialchars($card['document']) ?></span></span>
                                    <span class="mb-2 text-xs">Access Token:
                                        <span class="text-dark ms-sm-2 font-weight-bold"><?= md5($card['document']) ?></span></span>
                                </div>
                            </div>
                            <div class="card-footer">
                                <div class="ms-auto text-end">
                                    <a class="btn btn-link text-success px-3 mb-0" href="javascript:;">
                                        <i class="fas fa-wrench me-2"></i>Customize</a>
                                    <a class="btn btn-link text-danger px-3 mb-0" href="javascript:;">
                                        <i class="far fa-trash-alt me-2"></i>Delete</a>
                                    <a class="btn btn-link text-info px-3 mb-0" href="javascript:;">
                                        <i class="fas fa-pencil-alt me-2" aria-hidden="true"></i>Edit</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dell\Desktop\laravel-projects\secondMindAdmin\resources\views//agentForm.blade.php ENDPATH**/ ?>