<!-- footer start -->
 <footer class="footer widget-footer overflow-hidden clearfix">
    <div class="first-footer">
       <div class="container">
          <div class="grid grid-cols-12 mx items-center">
             <div class="lg:col-span-6  col-span-12 px widget-area">
                <aside id="enhancedtextwidget-2" class="widget-even widget-2 widget widget_text enhanced-text-widget">
                   <div class="textwidget widget-text">
                      <h4 class="prt-title-five res-991-mb-30"> Start your AI chatboot&nbsp;business journey with us </h4>
                   </div>
                </aside>
             </div>
             <div class="lg:col-span-6  col-span-12 px widget-area">
                <div class="widget widget_newsletter  clearfix">
                   <div class="widget-form">
                      <form id="subscribe-form" class="newsletter-form" method="post" action="#"
                         data-mailchimp="true">
                         <div class="mailchimp-inputbox clearfix" id="subscribe-content">
                            <div class="mailchimp-email">
                               <input type="email" name="email" placeholder="Email address" required="">
                            </div>
                         </div>
                         <button class="prt-footer" type="submit"> <i class="icon-right-2"></i></button>
                      </form>
                   </div>
                </div>
             </div>
          </div>
       </div>
    </div>  
    <div class="bottom-footer">
       <div class="container">
          <div class=" bottom-footer-border m-0">
             <div class="grid grid-cols-12 mx">
                <div class="lg:col-span-4 md:col-span-6 sm:col-span-6 col-span-12 px widget-area">
                   <div class="widget widget_text footer-widget-box res-991-mb-0">
                      <h3 class="widget-title-h3">Company</h3>
                      <div class="footer-menu-links">
                         <ul class="footer-menu-list m-0 p-0">
                            <li class="footer-menu-item"><a href="index-2.html" class="footer-menu-item-link">Home</a></li>
                            <li class="footer-menu-item"><a href="service-details.html" class="footer-menu-item-link">Website</a></li>
                            <li class="footer-menu-item"><a href="about-us.html" class="footer-menu-item-link">About us</a></li>
                            <li class="footer-menu-item"><a href="service-details.html" class="footer-menu-item-link">Social media</a></li>
                            <li class="footer-menu-item"><a href="blog.html" class="footer-menu-item-link">Blog</a></li>
                            <li class="footer-menu-item"><a href="service-details.html" class="footer-menu-item-link">Voice assistants</a></li>
                            <li class="footer-menu-item"><a href="our-team.html" class="footer-menu-item-link">Our team</a></li>
                            <li class="footer-menu-item"><a href="service-details.html" class="footer-menu-item-link">High image quality</a></li>
                            <li class="footer-menu-item"><a href="contact-us.html" class="footer-menu-item-link">Contact us</a></li>
                            <li class="footer-menu-item"><a href="service-details.html" class="footer-menu-item-link">Tech innovation</a></li>
                            <li class="footer-menu-item"><a href="portfolio.html" class="footer-menu-item-link">Our portfolio</a></li>
                         </ul>
                   </div>
                   </div>
                </div>
                <div class="lg:col-span-4 md:col-span-6 sm:col-span-6 col-span-12 px widget-area">
                   <div class="widget widget_text footer-widget-box res-575-mt-0">
                      <h3 class="widget-title-h3">Visit our office</h3>
                         <ul class=" footer-cta-list p-0 m-0">
                            <li class="list-items">Call us : <a href="tel:456789012">  +456 789012 </a >or<a class="tel:456789012"> 456 7890 22  </a></li>
                            <li class="list-items"><a href="mail:aichatboot123@example.com"> aichatboot123@example.com </a></li>
                            <li class="list-items">Location : 1234 Innovation lane, suite tech</li>
                         </ul>
                         <div class="social-icons">
                            <ul class="footer-social-icons">
                               <li class="footer-social-icons-item">
                                  <a href="#" target="_blank" class="footer-social-icons-link">Facebook</a>
                               </li>
                               <li class="footer-social-icons-item">
                                  <a href="#" target="_blank" class="footer-social-icons-link">Twitter</a>
                               </li>
                               <li class="footer-social-icons-item">
                                  <a href="#" target="_blank" class="footer-social-icons-link">Instagram</a>
                               </li>
                               <li class="footer-social-icons-item">
                                  <a href="#" target="_blank" class="footer-social-icons-link">linkedin</a>
                               </li>
                               <li class="footer-social-icons-item">
                                  <a href="#" target="_blank" class="footer-social-icons-link">Pinterest</a>
                               </li>
                            </ul>
                         </div>
                   </div>
                </div>
                <div class="lg:col-span-4 md:col-span-6 sm:col-span-6 col-span-12 px widget-area">
                   <div class="widget widget_text footer-widget-box res-991-mt-0">
                      <div class="prt-aboutbox res-991-mt-0">  
                         <h2># The role of science in the world</h2>
                         <h3>Thin like artificial Inteligence
                         always a positive</h3>
                         <a href="about-us.html" class="prt-btn prt-btn prt-btn-color-skincolor"> About us</a>
                      </div>
                   </div>
                </div>
             </div>
             <div class=" bottom-footer-border">
                <div class="copyright justify-content-between align-items-center ">
                   <div class="cpy-text">
                      <p class="mb-0">© 2025  <a target="_blank" href="index-2.html">Ailabflow</a> by Themetechmount. All rights reserved</p>
                   </div>
                   <ul class="prt-list footer-nav-menu">
                      <li><a href="faq.html">Reading</a></li>
                      <li><a href="faq.html">Instruction</a></li>
                      <li><a href="faq.html">Changelog</a></li>
                      <li><a href="faq.html">Guide</a></li>
                   </ul>
                </div>
             </div>
          </div>
       </div>
    </div>
 </footer>
<!-- footer end --><?php /**PATH C:\Users\dell\Desktop\laravel-projects\secondMindAdmin\resources\views/smartbuddy/layout/footer.blade.php ENDPATH**/ ?>