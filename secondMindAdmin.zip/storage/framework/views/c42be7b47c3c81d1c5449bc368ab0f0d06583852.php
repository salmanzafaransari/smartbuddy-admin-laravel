
<?php $__env->startSection('content'); ?>
<div class="banner-section overflow-hidden">
   <div class="rev_sider_wide">
      <rs-module-wrap id="rev_slider_22_1_wrapper" data-alias="Advanced-Demo-Slider" data-source="gallery"
         style="visibility:hidden;background:transparent;padding:0;margin:0px auto;position:relative; width: 0px!important; height:900px; left:0!important ;">
         <rs-module id="rev_slider_22_1" style="" data-version="6.7.14">
            <rs-slides style="overflow: hidden; position: absolute;">
               <rs-slide style="position: absolute;" data-key="rs-43" data-title="Slide" data-anim="p:dark;"
                  data-in="o:0;" data-out="o:0;">
                  <img  src="<?php echo e(asset('smartbuddy/images/transparent.html')); ?>"  alt=""  title="banner-img1"  width="1920"  height="970" class="rev-slidebg tp-rs-img"  style="background-color:#f2f8fd;" />
                  <rs-layer id="slider-22-slide-43-layer-0" data-type="text" data-rsp_ch="on" data-xy="x:l,l,c,c,c;xo:15px,15px,30px,0px;y:m;yo:-150px,-150px,-180px,-130px,-130px;" 
                  data-text="w:normal;s:84,56,53,50,55;l:105,66,53,60,65;" data-frame_0="y:100%;" 
                  data-frame_0_mask="u:t;" data-frame_1="st:70;sp:1200;sR:70;" data-frame_1_mask="u:t;" data-frame_999="o:0;st:w;sR:7730;" style="z-index:10;font-family:'Halyard Display';">
                  Taping into the
                  </rs-layer>
                  <!--
                        -->
                  <rs-layer id="slider-22-slide-43-layer-1" data-type="text" data-rsp_ch="on" data-xy="x:l,l,c,c,c;xo:15px,15px,30px,0px,0px,0;y:m;yo:-50px,-70px,-80px,-50px,-50px,-50px;" 
                  data-text="w:normal;s:84,56,53,50,55;l:105,66,53,60,65;" data-frame_0="y:100%;" 
                  data-frame_0_mask="u:t;" data-frame_1="st:70;sp:1200;sR:70;" data-frame_1_mask="u:t;" data-frame_999="o:0;st:w;sR:7730;" style="z-index:10;font-family:'Halyard Display';">
                  potential of AI with
                  </rs-layer>
                  <!--
                     -->
                  <rs-layer id="slider-22-slide-43-layer-2" data-type="text" data-rsp_ch="on" data-xy="x:l,l,c,c,c;xo:15px,10px,30px,30px,30px,0;y:m;yo:50px,0px,20px,10px,50px,50px;" 
                  data-text="w:normal;s:84,56,53,50,55;l:105,66,53,55,65;" data-frame_0="y:100%;" 
                  data-frame_0_mask="u:t;" data-frame_1="st:70;sp:1200;sR:70;" data-frame_1_mask="u:t;" data-frame_999="o:0;st:w;sR:7730;" style="z-index:10;font-family:'Halyard Display';">
                  a 
                  </rs-layer>
                  <!--
                        -->
                  <rs-layer id="slider-22-slide-43-layer-3" data-type="text" data-rsp_ch="on" data-xy="x:l,l,c,c,c;xo:75px,50px,-30px,-30px,-30px,0;y:m;yo:70px,0px,0px,40px,30px,0px;" 
                  data-text="w:normal;s:84,56,53,50,55;l:105,66,63,60,65;" data-frame_0="y:100%;" 
                  data-frame_0_mask="u:t;" data-frame_1="st:70;sp:1200;sR:70;" data-frame_1_mask="u:t;" data-frame_999="o:0;st:w;sR:7730;" style="z-index:10;font-family:'Halyard Display';">
                  <div id="text"></div>
                  </rs-layer>

                  <rs-layer id="slider-22-slide-43-layer-4"
                  data-type="text"
                  data-rsp_ch="on"
                  data-xy="x:l,l,c,c,c;xo:15px,15px,30px,0px,0px,0;y:m;yo:180px,80px,90px,400px;"
                  data-text="w:normal;s:18,18,18,18;l:28,28,28,28,28;"
                  data-frame_0="y:100%;"
                  data-frame_0_mask="u:t;"
                  data-frame_1="st:70;sp:1200;sR:70;"
                  data-frame_1_mask="u:t;"
                  data-frame_999="o:0;st:w;sR:7730;"
                  style="z-index:10; font-family:'DM Sans'; width: auto; max-width: 620px;"
                  >
                     Creating a Super ChatBot for automating customer service involves<br>
                     <span>combining AI-powered features to handle inquiries.</span>
                  </rs-layer>

                  <!--
                     --><a id="slider-22-slide-43-layer-4-1" class="rs-layer prt-btn" href="contact-us.html" target="_self" data-type="text" data-rsp_ch="on"
                     data-xy="x:l,l,c,c,c;xo:15px,15px,0px,0px,0px,0;y:m;yo:260px,160px,175px,130px,130px,180px;"
                     data-text="w:normal;s:16,16,16;l:16,16,16;fw:500;" data-padding="t:15,15,15;r:30;b:15,15,15;l:30;" 
                     data-border="bos:solid;bgc:#5a06ef;boc:#5a06ef;bow:1px,1px,1px,1px;bor:10px;" 
                     data-frame_0="y:50,38,28,17;"
                     data-frame_1="st:230;sp:1200;sR:230;" data-frame_999="o:0;st:w;sR:7570;" data-frame_hover="c:#fff;bgc:#091625;boc:#091625;bor:10px,10px,10px,10px;bos:solid;bow:1px,1px,1px,1px;"
                     style="z-index:7;font-family:'DM Sans'; background-color:#5a06ef;">
                     Launch now
                  </a>
                  <rs-layer id="slider-22-slide-43-layer-5"
                  data-type="image" data-rsp_ch="on"
                  data-xy="x:l,l,l,c,c;xo:190px,200px,30px,0px,0px,0;y:m;yo:260px,160px,-62px,-40px,-30px,-100px;"
                  data-frame_0="y:100%;" data-frame_0_mask="u:t;" data-frame_1="st:70;sp:1200;sR:70;" data-frame_1_mask="u:t;" data-frame_999="o:0;st:w;sR:7730;"
                  style="z-index:10; font-family:'DM Sans'; width: auto; max-width: 620px;"
                  >
                     <img src="<?php echo e(asset('smartbuddy/images/slides/single-img-12.png')); ?>" alt="Icon or Image" style="width:40px; height:41px;" data-src-rs-ref="images/slides/single-img-12.png') }}" />
                  </rs-layer>
                  <rs-layer id="slider-22-slide-43-layer-6"
                  data-type="image"
                  data-rsp_ch="on"
                  data-xy="x:l,l,c,c,c;xo:255px,260px,100px,0px,0px,0;y:m;yo:250px,145px,-62px,-40px,-30px,-100px;"
                  data-frame_0="y:100%;"
                  data-frame_0_mask="u:t;"
                  data-frame_1="st:70;sp:1200;sR:70;"
                  data-frame_1_mask="u:t;"
                  data-frame_999="o:0;st:w;sR:7730;"
                  style="z-index:10; font-family:'DM Sans'; width: auto; max-width: 620px;"
                  >
                     <img src="<?php echo e(asset('smartbuddy/images/slides/rating02.png')); ?>" alt="Icon or Image" style="width:110px; height:20px;" data-src-rs-ref="images/slides/rating02.png') }}" />
                  </rs-layer>
                  <rs-layer id="slider-22-slide-43-layer-7"
                  data-type="text"
                  data-rsp_ch="on"
                  data-xy="x:l,l,c,c,c;xo:255px,255px,30px,0px,0px,0;y:m;yo:280px,175px,-62px,-40px,-30px,-100px;"
                  data-text="w:normal;s:16,16,16,16;l:26,26,26,26,26;"
                  data-frame_0="y:100%;"
                  data-frame_0_mask="u:t;"
                  data-frame_1="st:70;sp:1200;sR:70;"
                  data-frame_1_mask="u:t;"
                  data-frame_999="o:0;st:w;sR:7730;"
                  style="z-index:10; font-family:'DM Sans'; width: auto;"
                  >
                  4.9/5.0 (from 20k reviews)
                  </rs-layer>
                  <rs-layer id="slider-22-slide-43-layer-8"
                  data-type="image"
                  data-rsp_ch="on"
                  data-xy="x:r,r,r,r,c;xo:10px,15px,15px,0px,0px,0;y:m;yo:20px,-40px,-150px,-40px,-30px,-100px;" 
                  data-frame_0="y:100%;"
                  data-frame_0_mask="u:t;"
                  data-frame_1="st:70;sp:1200;sR:70;"
                  data-frame_1_mask="u:t;"
                  data-frame_999="o:0;st:w;sR:7730;"
                  style="z-index:10; font-family:'DM Sans'; width: auto; min-width:542px; position:relative ; min-height:343px;"
                  >
                     <img src="<?php echo e(asset('smartbuddy/images/slides/banner-2.png')); ?>" alt="Icon or Image" style="width:815px; height:516px;" data-src-rs-ref="images/slides/banner-2.png') }}" />
                  </rs-layer>
                  <rs-layer id="slider-22-slide-43-layer-9" data-type="text" data-rsp_ch="on"
                     data-xy="x:r,r,c,c,c;xo:710px,480px,-145px,0px,0px,0;y:m;yo:-95px,-110px,-300px,-40px,-30px,-100px;" 
                     data-text="w:normal;s:15,10,10,15;l:25,20,20,;" data-frame_0="y:100%;" data-frame_0_mask="u:t;"
                     data-padding="t:15,10,15,18;r:30,20;b:15,10,15;l:30,20;" 
                     data-frame_1="st:400;sp:900;sR:1000;" data-frame_1_mask="u:t;"
                     data-frame_999="o:0;st:w;sR:7150;" style="z-index:11;font-family:'DM Sans';background-color:#5a06ef; border-radius:10px;">Hello Can i help you?
                  </rs-layer>
                  <rs-layer id="slider-22-slide-43-layer-10" data-type="text" data-rsp_ch="on"
                     data-xy="x:r,r,c,c,c;xo:620px,430px,550px,0px,0px,0;y:m;yo:0px,-30px,-62px,-40px,-30px,-100px;" 
                     data-text="w:normal;s:15,10,10,15;l:25,20,20;" data-frame_0="y:100%;" data-frame_0_mask="u:t;"
                     data-padding="t:15,10,15,18;r:30,20;b:15,10,15;l:30,20;" 
                     data-frame_1="st:400;sp:900;sR:1000;" data-frame_1_mask="u:t;"
                     data-frame_999="o:0;st:w;sR:7150;" style="z-index:11;font-family:'DM Sans';background-color:#5a06ef; border-radius:10px;">I'm an AI-powered chatbot <br> designed to assist and provide <br> information  to users.
                  </rs-layer>
                  <rs-layer id="slider-22-slide-43-layer-11" data-type="text" data-rsp_ch="on"
                     data-xy="x:r,r,c,c,c;xo:80px,80px,0px,0px,0px,0;y:m;yo:80px,30px,-62px,-40px,-30px,-100px;" 
                     data-text="w:normal;s:15,10,10,15;l:25,20,20;" data-frame_0="y:100%;" data-frame_0_mask="u:t;"
                     data-padding="t:15,10,15,18;r:30,20;b:15,10,15;l:30,20;" 
                     data-frame_1="st:400;sp:900;sR:1000;" data-frame_1_mask="u:t;"
                     data-frame_999="o:0;st:w;sR:7150;" style="z-index:11;font-family:'DM Sans';background-color:#fff; border-radius:10px;">Could you tell me more about<br> the Ailabflow?
                  </rs-layer>
               </rs-slide>
            </rs-slides>
         </rs-module>
      </rs-module-wrap>
   </div>
</div> 
<!-- site-main start -->
      <div class="site-main overflow-hidden">             
         <!-- about-section -->
         <section class="prt-row about-section position-relative overflow-hidden clearfix prt-bg bg-base-white">
            <div class="container">
               <div class="grid grid-cols-12 mx-15 items-center">
                  <div class="lg:col-span-6  col-span-12 px-15"> 
                     <div class="prt_single_image-wrapper  imagestyle-one">
                        <img class="img-fluid auto_size" src="<?php echo e(asset('smartbuddy/images/single-img-01.png')); ?>" alt="single-02" height="522" width="619">
                     </div>
                  </div>
                  <div class="lg:col-span-6 col-span-12 px-15 res-991-mt-30"> 
                     <div class="blog-contain">
                        <div class=" sm:m-auto  w-full"> 
                           <div class="section-title">
                              <div class="title-header">
                                 <h3 class="section-sub-title">What we do</h3>
                                 <h2 class="title">Explore limitless knowledge with our Ailabflow chats</h2>
                              </div>
                              <p>Sodales magna. Fusce eu nisl interdum, molestie nisi eu, pretium dolor nulla non erat in est egestas venenatis varius sollicitudin</p>
                           </div>
                        </div>
                        <div class="prt-list prt-bordered-lists prt-list-style-icon-02
                        prt-list-icon-color-skincolor prt-textcolor-darkgrey">
                           <div class="prt-list-li-content"><img src="<?php echo e(asset('smartbuddy/images/checkmarks-01.svg')); ?>" alt="checkmarks"><h3 class="prt-list-li-content-title">Ensuring Your Future Search Engine Optimize Dreams</h3></div>
                           <div class="prt-list-li-content"><img src="<?php echo e(asset('smartbuddy/images/checkmarks-01.svg')); ?>" alt="checkmarks"><h3 class="prt-list-li-content-title">Bring Your Brand to Life with Creative Social Content</h3></div>
                           <div class="prt-list-li-content"><img src="<?php echo e(asset('smartbuddy/images/checkmarks-01.svg')); ?>" alt="checkmarks"><h3 class="prt-list-li-content-title">Don’t just say that you care. Prove it as well</h3></div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- about-section end-->

         <!-- service-section -->
         <section class="prt-row service-section style-1 position-relative overflow-hidden clearfix prt-bg bg-base-white padding_top_zero-section ">
            <div class="container">
               <div class="text-center sm:m-auto  w-full"> 
                  <div class="section-title">
                     <div class="title-header mb-35">
                        <h2 class="title">Feel the power of AI by using our 
                           <br>chatbot services
                        </h2>
                     </div>
                  </div>
               </div>
               <div class="grid grid-cols-12 mx">
                  <div class="col-span-12 px "> 
                     <div class="featured-imagebox featured-imagebox-service style1 mt-0">
                        <div class="prt-service-imagebox"> 
                           <div class="prt-servicebox-title">
                              <div class="prt-box-title">
                                 <h4><a href="service-details.html">Website</a></h4></div>
                           </div>
                           <div class="featured-content">
                              <div class="featured-content-inner">
                                 <div class="prt-short-desc">Lead Generation Chatbots gather visitor information and assess their interest or potential as customers feedback and reviews.</div>
                              </div>
                              <!-- featured-content end -->
                           </div>
                           <div class="featured-thumbnail">
                              <img class="img-fluid" width="50" height="50" src="<?php echo e(asset('smartbuddy/images/service/service1.png')); ?>" alt="">
                           </div>
                           <!-- featured-content -->
                        </div>
                     </div>
                     <div class="featured-imagebox featured-imagebox-service style1 mt-0">
                        <div class="prt-service-imagebox"> 
                           <div class="prt-servicebox-title">
                              <div class="prt-box-title">
                                 <h4><a href="service-details.html">Social media</a></h4></div>
                           </div>
                           <div class="featured-content">
                              <div class="featured-content-inner">
                                 <div class="prt-short-desc">Task automation handles repetitive activities like answering frequently asked questions or booking appointments. </div>
                              </div>
                              <!-- featured-content end -->
                           </div>
                           <div class="featured-thumbnail">
                              <img class="img-fluid" width="50" height="50" src="<?php echo e(asset('smartbuddy/images/service/advocacy-1.png')); ?>" alt="">
                           </div>
                           <!-- featured-content -->
                        </div>
                     </div>
                     <div class="featured-imagebox featured-imagebox-service style1 mt-0">
                        <div class="prt-service-imagebox"> 
                           <div class="prt-servicebox-title">
                              <div class="prt-box-title">
                                 <h4><a href="service-details.html">Voice assistants</a></h4></div>
                           </div>
                           <div class="featured-content">
                              <div class="featured-content-inner">
                                 <div class="prt-short-desc">E-commerce assistants help users with product searches, offer recommendations, and support during the buying process. </div>
                              </div>
                              <!-- featured-content end -->
                           </div>
                           <div class="featured-thumbnail">
                              <img class="img-fluid" width="50" height="50" src="<?php echo e(asset('smartbuddy/images/service/email1.png')); ?>" alt="">
                           </div>
                           <!-- featured-content -->
                        </div>
                     </div>
                     <div class="featured-imagebox featured-imagebox-service style1 mt-0">
                        <div class="prt-service-imagebox"> 
                           <div class="prt-servicebox-title">
                              <div class="prt-box-title">
                                 <h4><a href="service-details.html">High image quality</a></h4></div>
                           </div>
                           <div class="featured-content">
                              <div class="featured-content-inner">
                                 <div class="prt-short-desc">High image quality refers to images with sharp details, accurate colors, and high resolution, making them clear and visually appealing. </div>
                              </div>
                              <!-- featured-content end -->
                           </div>
                           <div class="featured-thumbnail">
                              <img class="img-fluid" width="50" height="50" src="<?php echo e(asset('smartbuddy/images/service/social-media-marketing-1.png')); ?>" alt="">
                           </div>
                           <!-- featured-content -->
                        </div>
                     </div>
                  </div>
               </div>
               <div class="text-center sm:m-auto  w-full mt-20 mb-14"> 
                  <div class="prt-button-wrapper">
                     <a href="service.html" class="prt-btn">View all services</a>
                  </div>
               </div>
            </div>
         </section>
         <!-- product-section end-->

         <!--appointment-section -section -->
         <section class="prt-row appointment-section position-relative clearfix bg-img1 ">
            <div class="container p-0 res-991-pl-15 res-991-pr-15">
               <div class="flex width-100 float-right prt-right-span prt-bg bg-base-skin items-center mr_500">
                  <div class="prt-col-wrapper-bg-layer prt-bg-layer">
                     <div class="prt-bg-layer-inner"></div>
                  </div>
                  <div class="prt-left-spaceing"> 
                     <div class="prt-content sm:m-auto  w-full pl-55 res-767-pl-15"> 
                        <div class="section-title mb-20">
                           <div class="title-header mb-15 res-991-mb-0">
                              <h3 class="section-sub-title text-white">Working style</h3>
                              <h2 class="title text-white">Our ailabflow chatbot working step by process</h2>
                           </div>
                           <p>Sodales magna. Fusce eu nisl interdum, molestie nisi eu, pretium dolor nulla non erat in est egestas venenatis varius sollicitudin</p>
                        </div>
                     </div>
                  </div>
                  <div class="prt-second-spaceing"> 
                     <div class="prt-widget-container">
                        <ul class="prt-icon-list-items p-0 m-0">
                           <li class="prt-icon-list-item">
                              <span class="prt-icon-list-text">A - Content Creation &amp; Marketing</span>
                           </li>
                           <li class="prt-icon-list-item">
                              <span class="prt-icon-list-text">B - Digital Transformation Consulting</span>
                           </li>
                           <li class="prt-icon-list-item">
                              <span class="prt-icon-list-text">C - Digital Marketing Strategies</span>
                           </li>
                           <li class="prt-icon-list-item">
                              <span class="prt-icon-list-text">D - Diversify Revenue Streams</span>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- appointment-section-end -->

         <!-- testimonial-section -->
         <section class="prt-row  testimonial-section clearfix prt-bg bg-base-grey">
            <div class="container">
               <div class="text-center sm:m-auto  w-full"> 
                  <div class="section-title">
                     <div class="title-header pt-75 res-991-pt-50">
                        <h2 class="title pb-10 mb-40"> Dependable feedback from clients</h2>
                     </div>
                  </div>
               </div>
               <div class="grid grid-cols-12 mx slick_slider" data-slick='{"slidesToShow": 3, "slidesToScroll": 1, "arrows":false, "autoplay":false, "dots":false, "infinite":true, "responsive":[{"breakpoint":1199,"settings":{"slidesToShow": 3}}
                     ,{"breakpoint":1025,"settings":{"slidesToShow": 2}},{"breakpoint":991,"settings":{"slidesToShow": 1}},{"breakpoint":768,"settings":{"slidesToShow": 1}},{"breakpoint":481,"settings":{"slidesToShow": 1}},{"breakpoint":376,"settings":{"slidesToShow": 1}}]}'>
                  <div class="lg:col-span-4 md:col-span-4 sm:col-span-6 col-span-12 px">
                     <div class="testimonials prt-testimonial-box style1">
                        <div class="testimonial-content">
                           <blockquote class="testimonial-text">I recently integrated a chatbot into my business and it has been a game-changer. The chatbot not provides instant responses to customer.</blockquote>
                        </div>
                        <div class="testimonial-avatar flex">
                           <div class="testimonial-img ">
                              <img width="71" height="71" class="img-fluid" src="<?php echo e(asset('smartbuddy/images/testimonial/testimonial-01.png')); ?>" alt="testimonial-img">
                           </div>
                           <div class="testimonial-caption">
                              <h3>Millon Zahino</h3>
                              <span> Manager</span>
                           </div>
                        </div> 
                     </div>
                  </div>
                  <div class="lg:col-span-4 md:col-span-4 sm:col-span-6 col-span-12 px">
                     <div class="testimonials prt-testimonial-box style1">
                        <div class="testimonial-content">
                           <blockquote class="testimonial-text">The chatbot handles routine inquiries efficiently, freeing up our team to focus on complex cases integration was seamless and the ability.</blockquote>
                        </div>
                        <div class="testimonial-avatar flex">
                           <div class="testimonial-img ">
                              <img width="71" height="71" class="img-fluid" src="<?php echo e(asset('smartbuddy/images/testimonial/testimonial-02.png')); ?>" alt="testimonial-img">
                           </div>
                           <div class="testimonial-caption">
                              <h3>Penny Kat</h3>
                              <span>Business Owner</span>
                           </div>
                        </div> 
                     </div>
                  </div>
                  <div class="lg:col-span-4 md:col-span-4 sm:col-span-6 col-span-12 px">
                     <div class="testimonials prt-testimonial-box style1">
                        <div class="testimonial-content">
                           <blockquote class="testimonial-text">We partnered with AIlabflow to develop a custom AI solution for our customer service department the chatbot technology  service department solution for.</blockquote>
                        </div>
                        <div class="testimonial-avatar flex">
                           <div class="testimonial-img ">
                              <img width="71" height="71" class="img-fluid" src="<?php echo e(asset('smartbuddy/images/testimonial/testimonial-01.png')); ?>" alt="testimonial-img">
                           </div>
                           <div class="testimonial-caption">
                              <h3>Penny Rider</h3>
                              <span>Business Owner</span>
                           </div>
                        </div> 
                     </div>
                  </div>
                  <div class="lg:col-span-4 md:col-span-4 sm:col-span-6 col-span-12 px">
                     <div class="testimonials prt-testimonial-box style1">
                        <div class="testimonial-content">
                           <blockquote class="testimonial-text">Ai.agency transformed our customer experience. Their AI-driven approach not only improved our sales but also deepened our cusips.</blockquote>
                        </div>
                        <div class="testimonial-avatar flex">
                           <div class="testimonial-img ">
                              <img width="71" height="71" class="img-fluid" src="<?php echo e(asset('smartbuddy/images/testimonial/testimonial-03.png')); ?>" alt="testimonial-img">
                           </div>
                           <div class="testimonial-caption">
                              <h3>Hardin Smith</h3>
                              <span>CEO Of Founder</span>
                           </div>
                        </div>  
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!--team-member-section-1-->

         <!-- client-section -->
         <section class="prt-row client-section base-secondary-dark overflow-hidden clearfix prt-bg bg-base-white">
            <div class="container">
               <div class=" sm:m-auto  w-full text-center"> 
                  <div class="section-title mb-20">
                     <div class="title-header mb-35">
                        <h2 class="title">Trusted by 20,000+ marketing departments.</h2>
                     </div>  
                  </div>
               </div>
               <div class="w-full  flex  slick_slider" data-slick='{"slidesToShow": 5, "slidesToScroll": 1, "arrows":false, "autoplay":true, "dots":false, "infinite":true, "autoplaySpeed": 3000,"responsive":[{"breakpoint":1199,"settings":{"slidesToShow": 5}}
                     ,{"breakpoint":1024,"settings":{"slidesToShow": 3}},{"breakpoint":768,"settings":{"slidesToShow": 2}},{"breakpoint":481,"settings":{"slidesToShow": 1}},{"breakpoint":376,"settings":{"slidesToShow": 1}}]}'>
                  <div class="client-box ">
                     <div class="client-thumbnail">
                        <div class="prt-item-thumbnail-inner">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-1.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                        <div class="prt-client-logo-hover">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-1.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                     </div>
                  </div>
                  <div class="client-box ">
                     <div class="client-thumbnail">
                        <div class="prt-item-thumbnail-inner">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-2.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                        <div class="prt-client-logo-hover">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-2.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                     </div>
                  </div>
                  <div class="client-box">
                     <div class="client-thumbnail">
                        <div class="prt-item-thumbnail-inner">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-3.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                        <div class="prt-client-logo-hover">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-3.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                     </div>
                  </div>
                  <div class="client-box">
                     <div class="client-thumbnail">
                        <div class="prt-item-thumbnail-inner">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-5.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                        <div class="prt-client-logo-hover">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-5.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                     </div>
                  </div>
                  <div class="client-box">
                     <div class="client-thumbnail">
                        <div class="prt-item-thumbnail-inner">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-6.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                        <div class="prt-client-logo-hover">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-6.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                     </div>
                  </div>
                  <div class="client-box">
                     <div class="client-thumbnail">
                        <div class="prt-item-thumbnail-inner">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-7.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                        <div class="prt-client-logo-hover">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-7.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                     </div>
                  </div>
               </div>
               <div class="w-full  flex  slick_slider clint-slider-2" data-slick='{"slidesToShow": 4, "slidesToScroll": 1, "arrows":false, "autoplay":true, "dots":false,"autoplaySpeed": 5000, "infinite":true, "responsive":[{"breakpoint":1199,"settings":{"slidesToShow": 4}}
                     ,{"breakpoint":1024,"settings":{"slidesToShow": 2}},{"breakpoint":768,"settings":{"slidesToShow": 2}},{"breakpoint":575,"settings":{"slidesToShow": 1}},{"breakpoint":376,"settings":{"slidesToShow": 1}}]}'>
                  <div class="client-box ">
                     <div class="client-thumbnail">
                        <div class="prt-item-thumbnail-inner">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-1.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                        <div class="prt-client-logo-hover">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-1.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                     </div>
                  </div>
                  <div class="client-box ">
                     <div class="client-thumbnail">
                        <div class="prt-item-thumbnail-inner">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-2.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                        <div class="prt-client-logo-hover">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-2.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                     </div>
                  </div>
                  <div class="client-box">
                     <div class="client-thumbnail">
                        <div class="prt-item-thumbnail-inner">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-3.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                        <div class="prt-client-logo-hover">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-3.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                     </div>
                  </div>
                  <div class="client-box">
                     <div class="client-thumbnail">
                        <div class="prt-item-thumbnail-inner">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-5.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                        <div class="prt-client-logo-hover">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-5.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                     </div>
                  </div>
                  <div class="client-box">
                     <div class="client-thumbnail">
                        <div class="prt-item-thumbnail-inner">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-6.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                        <div class="prt-client-logo-hover">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-6.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                     </div>
                  </div>
                  <div class="client-box">
                     <div class="client-thumbnail">
                        <div class="prt-item-thumbnail-inner">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-7.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                        <div class="prt-client-logo-hover">
                           <img src="<?php echo e(asset('smartbuddy/images/client/client-7.png')); ?>" loading="lazy" alt="client-logo" class="client-box-image img-fluid" width="126" height="30">
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- client-section end-->

         <!-- contact-section 1-->
         <section class="prt-row ctn-section position-relative overflow-hidden clearfix bg-img2">
            <div class="container">
               <div class="grid grid-cols-12 mx items-center">
                  <div class="lg:col-span-7  col-span-12 px"> 
                     <div class="section"> 
                        <div class="section-title">
                           <div class="title-header mb-30">
                              <h2 class="title">Smart strategies for <br>chatbot business</h2>
                           </div>
                        </div>
                        <div  class="button">
                           <a href="contact-us.html" class="prt-btn prt-btn-color-skincolor">Get in touch</a>
                        </div>
                        <div class="section-heading pt-100 res-991-pt-30">
                           <h3>Let's talk</h3>
                        </div>
                     </div>
                  </div>
                  <div class="lg:col-span-5 col-span-12 px pl-55 res-991-pl-15 m-auto  mr-0 ml-0 "> 
                     <div class="featured-imagebox featured-imagebox-counter style1 mt-0">
                        <div class="prt-counter-imagebox"> 
                           <!-- featured-content -->
                           <div class="featured-content">
                              <div class="featured-content-inner">
                                 <div class="prt-content-subheading"> 
                                    <h4>Pharetra nunc ut adipiscing sed. nibh nam</h4>
                                 </div>
                                 <div class="prt-content-heading"> 
                                    <h2>20 <span> + </span></h2>
                                 </div>
                                 <div class=" prt-content-desc"> 
                                    Years of Experience
                                 </div>
                              </div>
                              <!-- featured-content end -->
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!--contact-section end-->

         <!-- blog-section -->
         <section class="prt-row blog-section-1 position-relative overflow-hidden clearfix prt-bg bg-base-grey  ">
            <div class="container">
               <div class="text-center sm:m-auto  w-full"> 
                  <div class="section-title">
                     <div class="title-header mb-35">
                        <h2 class="title"> AI Insights, innovations and impact</h2>
                     </div>
                  </div>
               </div>
               <div class="grid grid-cols-12 mx">
                  <div class="lg:col-span-4 md:col-span-6  col-span-12 px res-991-mb-10 "> 
                     <div class="featured-imagebox featured-imagebox-blog style1 mt-0 ">
                        <div class="prt-product-imagebox"> 
                           <div class="featured-thumbnail">
                              <a href="blog-details.html">
                                 <img class="img-fluid" width="1200" height="800" src="<?php echo e(asset('smartbuddy/images/blog/blog1.jpg')); ?>" alt="">
                              </a>
                           </div>
                           <!-- featured-content -->
                           <div class="featured-content">
                              <div class="featured-content-inner">
                                 <div class="featured-title"> 
                                    <a href="blog-details.html">
                                       <h2>Essential benefits of regular physiotherapy</h2>
                                    </a>
                                 </div>
                                 <div class="prt-content-desc">
                                    Transforming customer experience with ai powered solutions What are your cor...
                                 </div>
                                 <div class="prt-bottombox">
                                    <div class="prt-box-date">
                                       <span>Oct</span>16 2024              
                                    </div>
                                    <a href="#" class="prt-meta-like-link" tabindex="0">
                                    <i class="flaticon-heart-2 mt-10"></i> 10 like </a>
                                 </div>
                              </div>
                              <!-- featured-content end -->
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="lg:col-span-4 md:col-span-6  col-span-12 px res-767-mb-10 "> 
                     <div class="featured-imagebox featured-imagebox-blog style1 mt-0">
                        <div class="prt-product-imagebox"> 
                           <div class="featured-thumbnail">
                              <a href="blog-details.html">
                                 <img class="img-fluid" width="1200" height="800" src="<?php echo e(asset('smartbuddy/images/blog/blog2.jpg')); ?>" alt="">
                              </a>
                           </div>
                           <!-- featured-content -->
                           <div class="featured-content">
                              <div class="featured-content-inner">
                                 <div class="featured-title"> 
                                    <a href="blog-details.html">
                                       <h2>From hype to reality real world applications of ai</h2>
                                    </a>
                                 </div>
                                 <div class="prt-content-desc">
                                    Transforming customer experience with ai powered solutions What are your cor...
                                 </div>
                                 <div class="prt-bottombox">
                                    <div class="prt-box-date">
                                       <span>Aug</span> 24 2024
                                    </div>
                                    <a href="#" class="prt-meta-like-link"  tabindex="0">
                                    <i class="flaticon-heart-2 mt-5"></i> 3</a>
                                 </div>
                              </div>
                              <!-- featured-content end -->
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="lg:col-span-4 md:col-span-6  col-span-12 px ">
                     <div class="featured-imagebox featured-imagebox-blog style1 mt-0">
                        <div class="prt-product-imagebox"> 
                           <div class="featured-thumbnail">
                              <a href="blog-details.html">
                                 <img class="img-fluid" width="1200" height="800" src="<?php echo e(asset('smartbuddy/images/blog/blog3.jpg')); ?>" alt="">
                              </a>
                           </div>
                           <!-- featured-content -->
                           <div class="featured-content">
                              <div class="featured-content-inner">
                                 <div class="featured-title"> 
                                    <a href="blog-details.html">
                                       <h2>Maximizie your business innovative solutions</h2>
                                    </a>
                                 </div>
                                 <div class="prt-content-desc">
                                    Transforming customer experience with ai powered solutions What are your cor...
                                 </div>
                                 <div class="prt-bottombox">
                                    <div class="prt-box-date">
                                       <span>Aug</span> 24 2024
                                    </div>
                                    <a href="#" class="prt-meta-like-link" id="pid-5413" tabindex="0">
                                    <i class="flaticon-heart-2 mt-5"></i> 3</a>
                                 </div>
                              </div>
                              <!-- featured-content end -->
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- blog-section end-->

         <!-- contact-section 1-->
         <section class="prt-row contact-section position-relative overflow-hidden clearfix prt-bg bg-base-skin style-1">
            <div class="container">
               <div class="grid grid-cols-12 mx">
                  <div class="lg:col-span-4  md:col-span-6 col-span-12 px"> 
                     <div class="featured-icon-box icon-align-before-content style1">
                        <div class="featured-icon mb-10 text-center">
                           <div class="prt-icon prt-icon_element-onlytxt prt-icon_element-size-lg prt-icon_element-color-darkcolor">
                              <i class="flaticon flaticon-call-center"></i>
                           </div>
                        </div>
                        <div class="featured-content text-center">
                           <div class="featured-title">
                              <h3>Have a question? call us now</h3>
                           </div>
                           <div class="featured-desc">
                              <div class="featured-list">
                                 Office 1:  <span><a href="tel:1234567890">+(03) 0106 387 4456</a></span>
                              </div>
                              <div class="featured-list">
                                 Office 2:  <span><a href="tel:1234567890">+(03) 0106 387 4456</a></span>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="lg:col-span-4 md:col-span-6 col-span-12 px"> 
                     <div class="featured-icon-box icon-align-before-content style1">
                        <div class="featured-icon mb-10 text-center">
                           <div class="prt-icon prt-icon_element-onlytxt prt-icon_element-size-lg prt-icon_element-color-darkcolor">
                              <i class="flaticon flaticon-email-1"></i>
                           </div>
                        </div>
                        <div class="featured-content text-center">
                           <div class="featured-title">
                              <h3>Need support? Drop us an email</h3>
                           </div>
                           <div class="featured-desc">
                              <div class="featured-list">
                                <a href="mailto:info@domainname.com">info@domainname.com</a>
                              </div>
                              <div class="featured-list">
                                <a href="mailto:support@domainname.com">support@domainname.com </a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="lg:col-span-4 md:col-span-6 col-span-12 px"> 
                     <div class="featured-icon-box icon-align-before-content style1">
                        <div class="featured-icon mb-10 text-center">
                           <div class="prt-icon prt-icon_element-onlytxt prt-icon_element-size-lg prt-icon_element-color-darkcolor">
                              <i class="flaticon flaticon-wall-clock"></i>
                           </div>
                        </div>
                        <div class="featured-content text-center">
                           <div class="featured-title">
                              <h3>We are open our office on</h3>
                           </div>
                           <div class="featured-desc">
                              <div class="featured-list">
                                 Mon – Sat 07:00 – 21:00 
                              </div>
                              <div class="featured-list">
                                 Sunday – Closed
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!--contact-section end-->
      </div>
      <!-- site-main start -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('smartbuddy.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dell\Desktop\laravel-projects\secondMindAdmin\resources\views/smartbuddy/home.blade.php ENDPATH**/ ?>