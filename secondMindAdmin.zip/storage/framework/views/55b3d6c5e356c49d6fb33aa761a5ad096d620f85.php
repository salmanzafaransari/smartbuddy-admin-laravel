<?php echo e($slot); ?>

<?php /**PATH C:\Users\dell\Desktop\laravel-projects\secondMindAdmin\resources\views/vendor/mail/text/panel.blade.php ENDPATH**/ ?>