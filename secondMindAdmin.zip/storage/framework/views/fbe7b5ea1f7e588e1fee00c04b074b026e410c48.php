<!-- header start -->
<header id="masthead" class="header prt-header-style-01">
   <!-- site-header-menu -->
   <div id="site-header-menu" class="site-header-menu bg-white  py-4">
      <div class="site-header-menu-inner">
         <div class="container-fluid">
            <!-- Left: Logo -->
            <div class="site-navigation flex items-center justify-between">
            <a href="index-2.html" class="home-link flex items-center">
               <img src="<?php echo e(asset('smartbuddy/images/Demo03.svg')); ?>" alt="logo-img" class="w-auto">
            </a>
               <!-- menu-link -->
               <div class="menu-link flex items-center space-x-6">
                  <div class="btn-show-menu-mobile menubar menubar--squeeze">
                     <span class="menubar-box">
                     <span class="menubar-inner"></span>
                     </span>
                  </div>
                  <!-- menu -->
                  <nav class="main-menu menu-mobile justify-end" id="menu">
                     
                     <ul class="menu">
                        <li class="mega-menu-item active">
                           <a href="#" class="mega-menu-link">Home</a>
                           <ul class="mega-submenu">
                              <li><a href="https://themetechmount.com/tailwind/ailabflow/demo1" >Image generator</a></li>
                              <li><a href="https://themetechmount.com/tailwind/ailabflow/demo2">Agency</a></li>
                              <li><a href="https://themetechmount.com/tailwind/ailabflow/demo3">Information & technology</a></li>
                              <li><a href="https://themetechmount.com/tailwind/ailabflow/demo4">Digital Shop</a></li>
                              <li><a href="https://themetechmount.com/tailwind/ailabflow/demo5">Chatbot</a></li>
                              <li><a href="https://themetechmount.com/tailwind/ailabflow/demo6">Text Generator</a></li>
                           </ul>
                        </li>
                        <li class="mega-menu-item">
                           <a href="#" class="mega-menu-link">Pages</a>
                           <ul class="mega-submenu">
                              <li class=""><a href="about-us.html" >About us</a></li>
                              <li><a href="contact-us.html">Contact us</a></li>
                              <li><a href="our-team.html" >Our team</a></li>
                              <li><a href="team-details.html">Team details</a></li>
                              <li><a href="faq.html">Faq</a></li>
                           </ul>
                        </li>
                        <li class="mega-menu-item">
                           <a href="service.html">Smart solutions</a>
                        </li>
                        <li class="mega-menu-item"><a href="blog.html">Latest news</a></li>
                        <li class="mega-menu-item"><a href="contact-us.html">Let’s chat</a></li>
                     </ul>
                     <div class="header_extra pl_35">
                        <div class="prt-button-wrapper">
                           <a class="prt-brn-header" href="contact-us.html">
                              Joining chatbots
                           </a>
                        </div>
                     </div>
                  </nav>
                  <!-- menu end -->  
               </div> 
            </div>
         </div>
      </div>
   </div>
   <!-- site-header-menu end-->
</header>
<!-- header end --><?php /**PATH C:\Users\dell\Desktop\laravel-projects\secondMindAdmin\resources\views/smartbuddy/layout/header.blade.php ENDPATH**/ ?>