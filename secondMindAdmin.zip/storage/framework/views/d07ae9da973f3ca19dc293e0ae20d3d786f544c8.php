<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="keywords" content="ailabflow – An advanced AI-powered text generation app that creates high-quality, contextually accurate content in seconds.Perfect for writers, marketers, and creators looking to boost productivity with cutting-edge AI technology.">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="description" content="Ailabflow - AI Agency Html Templates, Modern Tailwind CSS template, Responsive Tailwind Html Template, Tailwind CSS HTML template, Tailwind CSS landing page AI Technology Html Templates, Ailabflow - AI Agency and Technology Html Templates, Artificial Intelligence website template, DevFox – IT Solutions and Services Html Templates, Anomica – IT Solutions Html Templates, Fixtech – Computer & Mobile Repair Services WP Theme, AI startup theme, Saas, machine learning Html Templates, tech agency theme, digital innovation Html Templates, AI services template, modern tech Html Templates, responsive AI website theme, Elementor AI theme, latest AI Html Templatess 2025, UI/UX design, premium Html Templatess, AI business website, Preyan Technosys Pvt. Ltd, best tech themes, Html Templatess for startups">
   <title>AI Agency & Technology Tailwind CSS Template</title>
   <link rel="shortcut icon" href="images/favicon.png">
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('smartbuddy/css/animate.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('smartbuddy/css/all.min.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('smartbuddy/css/fontello.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('smartbuddy/css/flaticon.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('smartbuddy/css/flaticon_ailabflow.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('smartbuddy/css/themify-icons.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('smartbuddy/css/halyard.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('smartbuddy/css/font-awesome.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('smartbuddy/css/aos.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('smartbuddy/css/slick.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('smartbuddy/css/prettyPhoto.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('smartbuddy/css/shortcodes.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('smartbuddy/css/main.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('smartbuddy/css/megamenu.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('smartbuddy/css/responsive.css')); ?>">
   <link href="<?php echo e(asset('smartbuddy/src/output.css')); ?>" rel="stylesheet">
   <!-- REVOLUTION LAYERS STYLES -->
   <link rel='stylesheet' id='rs-plugin-settings-css' href="<?php echo e(asset('smartbuddy/revolution/css/rs6.css')); ?>">
   
</head>

<body>
   <!-- page start -->
   <div class="page overflow-hidden">
      <div class="main-box">

       <?php echo $__env->make('smartbuddy.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       
       <?php echo $__env->yieldContent('content'); ?>
      </div>

      <?php echo $__env->make('smartbuddy.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
   </div>


   
   <!-- Javascript -->
   <script src="<?php echo e(asset('smartbuddy/js/jquery-3.7.1.min.js')); ?>"></script>
   <script src="<?php echo e(asset('smartbuddy/js/jquery-migrate-3.4.1.min.js')); ?>"></script>
   <script src="<?php echo e(asset('smartbuddy/js/Scrolltrigger.js')); ?>"></script>
   <script src="<?php echo e(asset('smartbuddy/js/select2.min.js')); ?>"></script>
   <script src="<?php echo e(asset('smartbuddy/js/Splittext.js')); ?>"></script>
   <!-- <script src="<?php echo e(asset('smartbuddy/js/cursor.js')); ?>"></script> -->
   <script src="<?php echo e(asset('smartbuddy/js/cursor.min.js')); ?>"></script>
   <script src="<?php echo e(asset('smartbuddy/js/gsap.min.js')); ?>"></script>
   <script src="<?php echo e(asset('smartbuddy/js/gsap-animation.js')); ?>"></script>
   <script src="<?php echo e(asset('smartbuddy/js/jquery-validate.js')); ?>"></script>
   <script src="<?php echo e(asset('smartbuddy/js/jquery.prettyPhoto.js')); ?>"></script>
   <script src="<?php echo e(asset('smartbuddy/js/slick.min.js')); ?>"></script>
   <script src="<?php echo e(asset('smartbuddy/js/jquery-waypoints.js')); ?>"></script>
   <script src="<?php echo e(asset('smartbuddy/js/numinate.min.js')); ?>"></script>
   <script src="<?php echo e(asset('smartbuddy/js/imagesloaded.min.js')); ?>"></script>
   <script src="<?php echo e(asset('smartbuddy/js/jquery-isotope.js')); ?>"></script>
   <script src="<?php echo e(asset('smartbuddy/js/circle-progress.min.js')); ?>"></script>
   <script src="<?php echo e(asset('smartbuddy/js/main.js')); ?>"></script>
   <script src="<?php echo e(asset('smartbuddy/js/aos.js')); ?>"></script>
   <!-- <script src="<?php echo e(asset('revolution/public/js/libs/tptools.js')); ?>" id="_tpt-js" async></script>
   <script src="<?php echo e(asset('revolution/public/js/sr7.js')); ?>" id="sr7-js" async></script>
   <script src="<?php echo e(asset('revolution/public/js/page.js')); ?>" id="sr7-page-js" async></script> -->
   <script src="<?php echo e(asset('smartbuddy/revolution/js/revolution.tools.min.js')); ?>"></script>
   <script src="<?php echo e(asset('smartbuddy/revolution/js/rs6.min.js')); ?>"></script>
   <script src="<?php echo e(asset('smartbuddy/revolution/js/slider.js')); ?>"></script>
   <script>
      AOS.init({
         offset: 0,
         duration: 400,
         delay: 0,
         once: true,
      });
        
   </script>
   <!-- Revolution Slider -->
   <script src="<?php echo e(asset('smartbuddy/revolution/js/revolution.tools.min.js')); ?>"></script> 
   <script src="<?php echo e(asset('smartbuddy/revolution/js/rs6.min.js')); ?>"></script>
   <script src="<?php echo e(asset('smartbuddy/revolution/js/slider.js')); ?>"></script>
</body>

</html><?php /**PATH C:\Users\dell\Desktop\laravel-projects\secondMindAdmin\resources\views/smartbuddy/default.blade.php ENDPATH**/ ?>