<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartBuddy Dashboard</title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/favicon.png')); ?>">
    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo e(asset('vendor/fontawesome/css/all.min.css')); ?>" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <style>
         .bg-gredient{
        background: linear-gradient(135deg, rgb(102, 126, 234) 0%, rgb(118, 75, 162) 100%);
        }
    </style>

    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
        <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <main class="main-content">
            <?php echo $__env->make('layout.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </main>

    <!-- jQuery -->
    <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap JS -->
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Custom JS -->
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <script>
        function confirmLogout() {
            // show modal when logout clicked
            var modal = new bootstrap.Modal(document.getElementById('confirmModal'));
            modal.show();

            // attach event listener only once
            document.getElementById('confirmLogoutBtn').onclick = function () {
                document.getElementById('logout-form').submit();
            };
        }
    </script>
    

    <?php echo $__env->yieldContent('scripts'); ?>
    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->is_superuser): ?>
        <script>
            $(document).ready(function() {
                $.ajax({
                    url: "<?php echo e(route('users.count')); ?>",
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        console.log(response.data);

                        // Update sidebar count
                        $('#allUserCount').text(response.data);
                        $('.totalUsers').text(response.data);
                    },
                    error: function(xhr) {
                        console.log(xhr.responseText);
                        $('#allUserCount').text('0');
                        $('.totalUsers').text('0');
                    }
                });
                $.ajax({
                    url: "<?php echo e(route('tracker.trackCount')); ?>",
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        console.log(response.totalTrackerCount);
                        // Update sidebar count
                        $('#allTrackerCount').text(response.totalTrackerCount);
                    },
                    error: function(xhr) {
                        console.log(xhr.responseText);
                        $('#allTrackerCount').text('0');
                    }
                });
            });

        </script>
        <?php endif; ?>
    <?php endif; ?>
</body>

</html><?php /**PATH C:\Users\dell\Desktop\laravel-projects\secondMindAdmin\resources\views/default.blade.php ENDPATH**/ ?>