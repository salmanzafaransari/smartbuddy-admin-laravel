
<?php $__env->startSection('pageTitle', 'Add Chatbot'); ?>
<?php $__env->startSection('pageAction'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<style>
 .img-box{
  width:80px;
  height:80px;
  border:3px solid #fff;
  border-radius:50%;
  overflow:hidden;
  margin-top:-65px;
 }
 .img-box img{
  width: 100%;
  height:100%;
 }
 .bg-gredient{
  background: linear-gradient(135deg, rgb(102, 126, 234) 0%, rgb(118, 75, 162) 100%);
 }
 .fix-height{
  height:70px;
 }
 .select2-container--default .select2-results__option {
    padding: 10px 12px !important;  /* Increased from default 6px */
    line-height: 1.5 !important;
}

/* Increase dropdown max-height (optional) */
.select2-container--default .select2-results > .select2-results__options {
    max-height: 300px !important;  /* Default is 200px */
}

/* Larger scrollbar for better UX */
.select2-results__options::-webkit-scrollbar {
    width: 10px !important;
}
 .select2-selection--single{
  padding:5px;
  height:50px !important;
  border: 1px solid rgb(var(--border)) !important;
  border-radius: var(--border-radius-sm) !important;
 }
 .select2-selection__arrow {
  top:10px !important;
 }
 .select2-selection__rendered{
  padding-top:3px !important;
 }
 .select2-container--open {
    z-index: 1060 !important; /* Ensure dropdown appears above modals */
}

#customBusinessModal .modal-content {
    border: 2px solid var(--primary);
    box-shadow: 0 0 15px rgba(0, 123, 255, 0.2);
}

#customBusinessModal .invalid-feedback {
    display: none;
}

#customBusinessModal .is-invalid ~ .invalid-feedback {
    display: block;
}
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" integrity="sha512-nMNlpuaDPrqlEls3IX/Q56H36qvBASwb3ipuo3MxeWbsQB1881ox0cRv7UPTgBlriqoynt35KjEwgGUeUXIPnw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
      <form action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row g-4">
            <!-- Profile Picture Section -->
            <div class="col-lg-4">
                <div class="dashboard-card">
                    <div class="card-header">
                        <h5 class="card-title">Chatbot Image</h5>
                    </div>
                    <div class="card-body text-center">
                        <div class="profile-avatar mb-3">
                            <img width="100" src="<?php echo e(asset('assets/images/user-avatar.jpg')); ?>" alt="Profile" class="rounded-circle" id="profileImage">
                            <button type="button" class="btn btn-sm btn-primary avatar-edit" onclick="document.getElementById('imageUpload').click()">
                                <i class="fas fa-camera"></i>
                            </button>
                            <input type="file" name="profile_photo" id="imageUpload" accept="image/*" style="display: none;">
                        </div>
                        <p class="text-muted">Upload a new profile picture. JPG or PNG only.</p>
                    </div>
                </div>
            </div>

            <!-- Profile Info -->
            <div class="col-lg-8">
                <div class="dashboard-card">
                    <div class="card-header">
                        <h5 class="card-title">Chatbot Info</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                           <div class="col-md-6">
                               <label for="modelName" class="form-label">Chatbot Name</label>
                               <input type="text" class="form-control" id="modelName" required>
                           </div>
                           <div class="col-md-6">
                             <label for="modelType" class="form-label">Chatbot Type</label>
                             <select class="" id="businessTypeselect" required style="padding:5px 3px !important;">
                               <option value="">Select Business Type</option>
                               <!-- Education -->
                               <optgroup label="Education">
                                   <option value="school">School</option>
                                   <option value="college">College/University</option>
                                   <option value="online-learning">Online Learning Platform</option>
                                   <option value="tutoring">Tutoring Service</option>
                               </optgroup>
                               
                               <!-- Healthcare -->
                               <optgroup label="Healthcare">
                                   <option value="hospital">Hospital/Clinic</option>
                                   <option value="telemedicine">Telemedicine</option>
                                   <option value="mental-health">Mental Health App</option>
                                   <option value="pharmacy">Pharmacy</option>
                               </optgroup>
                               <!-- E-Commerce & Retail -->
                               <optgroup label="E-Commerce & Retail">
                                   <option value="ecommerce">Online Store</option>
                                   <option value="fashion">Fashion Brand</option>
                                   <option value="electronics">Electronics Retailer</option>
                                   <option value="local-shop">Local Shop</option>
                               </optgroup>
                               <!-- Finance & Banking -->
                               <optgroup label="Finance">
                                   <option value="bank">Bank</option>
                                   <option value="fintech">FinTech App</option>
                                   <option value="insurance">Insurance Company</option>
                               </optgroup>
                               <!-- Other Key Industries -->
                               <optgroup  label="Others">
                                 <option value="hospitality">Hospitality & Travel</option>
                                 <option value="real-estate">Real Estate</option>
                                 <option value="legal">Legal Services</option>
                                 <option value="tech">Tech/SaaS</option>
                                 <option value="entertainment">Entertainment & Media</option>
                                 <option value="government">Government Services</option>
                                 <option value="custom">Other (Specify)...</option>
                               </optgroup>
                               
                             </select>
                           </div>
                           <div class="col-12">
                               <label for="modelDescription" class="form-label">Description</label>
                               <textarea class="form-control" id="modelDescription" rows="3"></textarea>
                           </div>
                           <div class="col-md-6">
                               <label for="apiEndpoint" class="form-label">API Endpoint</label>
                               <input type="url" class="form-control" id="apiEndpoint">
                           </div>
                           <div class="col-md-6">
                               <label for="apiKey" class="form-label">API Key</label>
                               <input type="password" class="form-control" id="apiKey">
                           </div>
                           <div class="col-12">
                               <label for="modelTags" class="form-label">Tags (comma separated)</label>
                               <input type="text" class="form-control" id="modelTags" placeholder="e.g., language, generation, advanced">
                           </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-between mt-4">
                    <a href="javascript:history.back()" class="btn btn-outline-secondary">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                </div>
            </div>
        </div>
      </form>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js" integrity="sha512-2ImtlRlf2VVmiGZsjm9bEyhjGW4dU7B6TNwh/hx/iSByxNENtj3WVE6o/9Lj4TJeVXPi4bnOIMXFIJJAeufa0A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
 jQuery(document).ready(function($) {
     const $businessSelect = $('#businessTypeselect');
     
     
     
     // Initialize Select2 with proper configuration
     $businessSelect.select2({
         placeholder: "Select Business Type",
         width: '100%',
         dropdownParent: $('#addModelModal'),
         allowClear: true
     });

     // Handle custom option selection
     $businessSelect.on('select2:select', function(e) {
         // Check if "Other (Specify)..." was selected
         if (e.params.data.id === 'custom') {
             // Reset the selection
             $businessSelect.val(null).trigger('change');
             
             // Show custom input modal
             $('#customBusinessModal').modal('show');
             
             // Clear any previous input and focus
             $('#customBusinessInput').val('').focus();
         }
     });

     // Save custom business type
     $('#saveCustomBusiness').click(function() {
         const customValue = $('#customBusinessInput').val().trim();
         
         if (customValue) {
             // Create new option (both value and text same)
             const newOption = new Option(customValue, customValue, true, true);
             
             // Add it before the "Other (Specify)..." option
             $businessSelect.find('option[value="custom"]').before(newOption);
             $businessSelect.trigger('change');
             
             // Select the new option
             $businessSelect.val(customValue).trigger('change');
             
             // Close modal
             $('#customBusinessModal').modal('hide');
         } else {
             // Show validation error
             $('#customBusinessInput').addClass('is-invalid');
         }
     });

     // Clear validation when typing
     $('#customBusinessInput').on('input', function() {
         $(this).removeClass('is-invalid');
     });
     // var val = $businessSelect.val();
     // $('#businessTypeselect').on('change', function(e){
     //  const selectedValue = $('#businessTypeselect').val();
     //  console.log(selectedValue, 'jsldjflkdjflkdj');
     // })
 });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dell\Desktop\laravel-projects\secondMindAdmin\resources\views/chatbot/add.blade.php ENDPATH**/ ?>