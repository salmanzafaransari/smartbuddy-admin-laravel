@extends('default')
@section('pageTitle', 'Profile')
@section('pageAction')

@endsection
@section('content')
@endsection